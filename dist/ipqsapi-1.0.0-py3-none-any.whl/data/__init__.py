from .proxyvpn_data import ProxyVPNData
